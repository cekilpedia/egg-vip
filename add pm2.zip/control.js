// Buat Lu Yang Jual Sc Ini Yang Jujur Jangan Samp Nipu Apalagi Lari Dari Tanggung Jawab

// Base DHAFA NP : Copyan Dari Base Dika


const fs = require('fs')
const chalk = require('chalk')
const tiktok = require("./folder-root/lib/tiktok")
const facebook = require("./folder-root/lib/facebook")
const instagram = require("./folder-root/lib/instagram")
const twitter = require("./folder-root/lib/twitter")

global.ntnsfww = []
global.wlcm = []
global.wlcmm = []
//gausah di apa² in!
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
//=================================================//
//—————「 Set Kebutuhan Button & Kontak 」—————//
//ubah aja kalau ada yang gapunya gsh di hps anggap aja credits :), note tanda ' gausah di hapus!
global.youtube = 'https://youtube.com/@dmhost' // ubah aia
global.ig = '@dhaffnavy' // ubah aja
global.email = 'dhafa@dmhostz.my.id' //serah
global.region = 'indonesia' // serah
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'Dhafa Nazula P' //ubah jadi nama mu, note tanda ' gausah di hapus!
global.botname = 'DM BOTZ BUG V2.' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.footer = 'DM BOTZ BUG V2.' //ubah jadi nama mu, note tanda ' gausah di hapus!
//=================================================//
global.owner = ['31687888860','6288287765252','6285703186122'] // ubah aja pake nomor lu
global.creator = "31687888860@s.whatsapp.net"
global.premium = ['31687888860','687877577','6288287765252'] // ubah aja pake nomor lu
global.keyopenai = "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"
global.packname = 'DM BOTZ BUG V2' // ubah aja
global.ownerr = ['Dhafa Nazula P'] // ubaha aja
global.author = 'Dhafa Nazula P' //ubah aja
global.prefa = ['','!','.','🐦','🐤','🗿']
global.sessionName = 'dm' //Gausah Juga
global.sp = '⭔' // Gausah Juga

// Terserah
global.mess = {
    nsfw: '*Fitur NSFW tidak diaktifkan, chat admin grup supaya diaktifkan*_',
    owner: 'Maaf Kamu Bukan Pengguna Premium',
 }
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
//Terserah Kalau Paham 
global.thumb = fs.readFileSync("./folder-root/image/dm.jpg")
global.log0 = fs.readFileSync("./folder-root/image/dm.jpg")
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})